#include"Timer.h"

void Timer::start(){ t = time(NULL); }
time_t Timer::elapsedtime()
{ return time(NULL)-t; }










