
#include<ncurses.h>
#include"Snake.h"
#include"Timer.h"
#include<vector>
#include<cstdlib>

int main()
{

int width,height,conti=1,conti2=1;
int key,a=0,tl=0,g=0,xx,yy;
double x=0,y=1;


initscr();
cbreak();
noecho();
keypad(stdscr,TRUE);
nodelay(stdscr,TRUE);
getmaxyx(stdscr,height,width);
mvaddstr(0,0," Pressed Key: ");
Snake snake;
Timer timer;
time_t tt=0;
vector<int> leng;
vector<int> wall;
srandom(time(NULL));

int h,w = random()%width,l,d = random()%4,hh,ww;
while(1)
{
h = random()%height;
l = random()%20;
if(l != 0 && h!= 0)
break;
}
for(int i=0;i<2*l;++i)
wall.push_back(0);

switch(d)
{
	case 0 :
	for(int i=0;i<2*l;i = i+2)
	{
	wall.at(i+1) = h- (i/2);
	wall.at(i) = w;
	while( (h-(i/2) ) <1 )
	wall.at(i+1) = (height-1);
	while( (h-(i/2) ) >=height)
	wall.at(i+1) -= (height-1);
	mvaddstr(wall.at(i+1),wall.at(i),"1");
	} break;

	case 1 :
	for(int i=0;i<2*l;i = i+2)
	{
	wall.at(i+1) = h + (i/2);
	wall.at(i)=w;
	while( (h+(i/2)) <1)
	wall.at(i+1) += (height-1);
	while( (h+(i/2)) >=height)
	wall.at(i+1) -= (height-1);
	mvaddstr(wall.at(i+1),wall.at(i),"1");
	} break;

	case 2 :
	for(int i=0;i<2*l;i = i+2)
	{
	wall.at(i+1) =h;
	wall.at(i) = w+(i/2);
	while((w+(i/2))<0)
	wall.at(i) += width;
	while((w+(i/2))>=width)
	wall.at(i) -= width;
	mvaddstr(wall.at(i+1),wall.at(i),"1");
	} break;
	case 3 :
	for(int i=0;i<2*l;i = i+2)
	{
	wall.at(i+1) = h;
	wall.at(i) = w -(i/2);
	while((w-(i/2))<0)
	wall.at(i) += width;
	while((w-(i/2))>=width)
	wall.at(i) -= width;
	mvaddstr(wall.at(i+1),wall.at(i),"1");
	} break;
}

vector<int> wall_t(wall);


leng.push_back(0);
leng.push_back(0);
leng.push_back(1);
leng.push_back(1);


mvaddstr(y,x,"0");
start_color();

int g_m_y,g_m_x,grade=0;
while(1)
{
g_m_y = random()%height;
if(g_m_y)
break;
}
g_m_x = random()%width;
init_pair(1,COLOR_GREEN,COLOR_BLACK);
attrset(COLOR_PAIR(1));
mvaddstr(g_m_y,g_m_x,"$");
mvaddstr(0,50,"$ can get grade");
attrset(A_NORMAL);

int r_m_y,r_m_x,r_m_i=1;
while(1)
{
r_m_y = random()%height;
if(r_m_y)
break;
}
r_m_x = random()%width;
init_pair(2,COLOR_RED,COLOR_BLACK);
attrset(COLOR_PAIR(2));
mvaddstr(r_m_y,r_m_x,"$");
mvaddstr(0,70,"eating $ will die");
attrset(A_NORMAL);

int q_y,q_x,q_i=1;
while(1)
{
q_y = random()%height;
if(q_y)
break;
}
q_x = random()%width;
init_pair(3,COLOR_BLUE,COLOR_BLACK);
attrset(COLOR_PAIR(3));
mvaddstr(q_y,q_x,"?");
mvaddstr(0,90,"eating ? will 1. to increase length 4 or 5 2.can thought wall randomly");
attrset(A_NORMAL);

int j;

time_t q_t =0;


while(conti)
{
	while( (key = getch() ) ==ERR) 
	{
	xx =x;yy =y;
	if(leng.at(1) !=yy||leng.at(0) !=xx)
	{
	for(int i=2;i<leng.size();i = i+2)
	{
	if(leng.at(i+1) == leng.at(1) && leng.at(i) == leng.at(0) )
	{

	mvprintw(0,80,"%d %d",leng.at(i+1),leng.at(i));
	refresh();
	conti = 0;
	g = 2;
	break;
	}
 	}
	
	for(int i=0;i<2*l;i = i+2)
	{
	if(leng.at(1) == wall.at(i+1) && leng.at(0) == wall.at(i) )
	{
	conti =0;
	g=2;
	break;
	}
	
	}

	if(r_m_i)
	if(leng.at(1) == r_m_y && leng.at(0) ==r_m_x)
	{
	conti =0;
	g=2;
	}


	if(leng.at(1) == g_m_y && leng.at(0) == g_m_x)
	{
	++grade;
	while(1)
	{
	g_m_y = random()%height;
	if(g_m_y)
	break;
	}
	g_m_x = random()%width;
	attrset(COLOR_PAIR(1));
	mvaddstr(g_m_y,g_m_x,"$");
	attrset(A_NORMAL);
	
	}
	
	if(q_i)
	if(leng.at(1) ==q_y && leng.at(0) == q_x)
	{

			for(int i=0;i<wall.size();++i)
			wall.at(i) =0;	
			q_t = tt;

			attrset(A_BLINK);
	
			/*int lx,conti3;
			lx =4;
			for(int j=0;j<lx;++j)
			{
			leng.push_back(0);
			leng.push_back(0);
			}
			
			for(int j=lx-1;j>=0;--j)
			{
			conti3 =1;
			while(conti3)
			{
			
			
			snake.run(y,x);
			
			while(x<0)x+=width;
			while(x>=width)x-=width;
			while(y<1)y+=(height-1);
			while(y>=height)y-=(height-1);
			xx=x;yy=y;
			if(leng.at(1)!=yy || leng.at(0)!=xx)
			{
			for(int i=leng.size()-1-(2*j);i>1;i = i-2)
			{
			leng.at(i) = leng.at(i-2);
			leng.at(i-1) = leng.at(i-3);
			}
		
			leng.at(1)=y;leng.at(0)=x;
			
			for(int i=leng.size()-3-(2*j);i>1;i = i-2)
			mvaddstr(leng.at(i),leng.at(i-1),"o");

			mvaddstr(leng.at(1),leng.at(0),"0");
			conti3=0;
			mvprintw(0,50,"%d %d  %d %d  %d %d",leng.at(1),leng.at(0),leng.at(3),leng.at(2),leng.at(leng.size()-1),leng.at(leng.size()-2));
			refresh();
			}
			}
			}
*/
						
	}
	if(q_t)
	if(tt - q_t >10)
	{
	wall = wall_t;
	for(int i=0;i<wall.size();i=i+2)
	mvaddstr(wall.at(i+1),wall.at(i),"1");
	q_t =0;	
	}


	if(g==2)
	break;
	++g;
	for(int i= leng.size()-1;i>1;i = i-2)
	{
		leng.at( i ) = leng.at( i-2 );
		leng.at( i-1 ) = leng.at( i-3 );
	}
	
	leng.at(1) =y;
	leng.at(0) =x;
	}
	snake.run(y,x);
	
	while(x<0)x+=width;
	while(x>=width)x-=width;
	while(y<1)y+=(height-1);
	while(y>=height)y-=(height-1);

	if(g)
	{
	mvaddstr(leng.at(leng.size()-1),leng.at(leng.size()-2)," ");

	if(leng.size()-4)
	for(int i= leng.size()-3;i>1;i = i-2)
	mvaddstr(leng.at(i),leng.at(i-1),"o");
	mvaddstr(leng.at(1),leng.at(0),"0");
	g=0;
	}

//	mvprintw(0,35,"%f %f %f %f",leng.at(0),leng.at(1),leng.at(2),leng.at(3));
//	refresh();


	if(a)
	if( tt!=timer.elapsedtime() )
	{
	tt = timer.elapsedtime();
		if( tl != (tt/5) )
		{
			tl = tt/5;
			leng.push_back(0);
			leng.push_back(0);
			conti2 =1;
			while(conti2)
			{
			
			
			snake.run(y,x);
			
			while(x<0)x+=width;
			while(x>=width)x-=width;
			while(y<1)y+=(height-1);
			while(y>=height)y-=(height-1);
			xx=x;yy=y;
			if(leng.at(1)!=yy || leng.at(0)!=xx)
			{
			for(int i=leng.size()-1;i>1;i = i-2)
			{
			leng.at(i) = leng.at(i-2);
			leng.at(i-1) = leng.at(i-3);
			}
		
			leng.at(1)=y;leng.at(0)=x;
			
			for(int i=leng.size()-3;i>1;i = i-2)
			mvaddstr(leng.at(i),leng.at(i-1),"o");

			mvaddstr(leng.at(1),leng.at(0),"0");
			
			conti2 = 0;
			}
			}

			if( r_m_i )
			{
				r_m_i =0;
				mvaddstr(r_m_y,r_m_x," ");
				r_m_y=0;r_m_x=0;
			}
			else
			{
				r_m_i =1;
				while(1)
				{
					r_m_y = random()%height;
					if(r_m_y)
					break;
				}
				r_m_x = random()%width;
				attrset(COLOR_PAIR(2));
				mvaddstr(r_m_y,r_m_x,"$");
				attrset(A_NORMAL);
			}

			if( q_i )
			{
				q_i =0;
				mvaddstr(q_y,q_x," ");
				q_y=0;q_x=0;
			}
			else
			{
			q_i=1;
			while(1)
			{
				q_y = random()%height;
				if(q_y)
				break;
			}
			q_x = random()%width;
			attrset(COLOR_PAIR(3));
			mvaddstr(q_y,q_x,"?");
			attrset(A_NORMAL);
			}
	
			
		}
	mvprintw(0,21,"Time : %d  Grade : %d",tt,grade);
	refresh();
	}

	}


switch(key)
{

	case KEY_LEFT: snake.set_direction(4);
	mvaddstr(0,15,"Left ");
	if(!a){ ++a; timer.start(); }break;
	case KEY_RIGHT: snake.set_direction(2);
	mvaddstr(0,15,"Right");
	if(!a){ ++a; timer.start(); }break;
	case KEY_UP: snake.set_direction(1);
	mvaddstr(0,15,"UP   ");
	if(!a){ ++a; timer.start(); }break;
	case KEY_DOWN: snake.set_direction(3);
	mvaddstr(0,15,"Down ");
	if(!a){ ++a; timer.start(); }break;
	default: conti=0;
}

}
while(getch() == ERR)
mvaddstr(20,50,"Game over!!!!!!!");


endwin();
return 0;







}
