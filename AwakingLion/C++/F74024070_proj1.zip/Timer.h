#include<iostream>
#include<ctime>
#include<unistd.h>

using namespace std;

class Timer {
public:
void start();
time_t elapsedtime();
private:
time_t t;
};
