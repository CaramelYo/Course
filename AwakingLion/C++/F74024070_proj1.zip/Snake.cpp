#include"Snake.h"

Snake::Snake()
{
direction =0;
length = 0;
}

void Snake::set_direction(int d)
{
switch(d)
{	
	case 1 :
	if(direction != 3)
	direction = 1;
	break;
	
	case 2 :
	if(direction != 4)
	direction = 2;
	break;
	
	case 3 :
	if(direction != 1)
	direction = 3;
	break;

	case 4 :
	if(direction != 2)
	direction = 4;
	break;
}

}


double Snake::run(double&y,double&x)
{
switch(direction)
{
	
	
	case 1 : y=y-0.00003;
	break;

	case 2 : x=x+0.00005;
	break;
	
	case 3 : y=y+0.00003 ;
	break;

	case 4 : x=x-0.00005 ;
	break;
}

return 0;
}

int Snake::set_length(){ ++length; return length;}

//double* Snake::temp() {return dt;}





