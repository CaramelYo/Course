#include<iostream>
using namespace std;

class Snake
{

	public:
	Snake();
	void set_direction(int);
	int set_length();
	double run(double&,double&);
	int length;
	private:
	int direction;
};
