#ifndef P_H
#define P_H
#include<ncurses.h>
#include<iostream>
using namespace std;


class P
{
	public:
	P(double yy,int xx,int& w,int& h):y(yy),x(xx),width(w),height(h){};
	void stand(int&s){s =1;};
	virtual void paint(double&) = 0;
	virtual void hp(Person&) = 0;
	virtual void power(Person&,int&) = 0;
	int x;
	double y;
	int width;
	int height;

};
#endif
