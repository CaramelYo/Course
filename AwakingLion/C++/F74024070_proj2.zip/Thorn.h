#include"P.h"

class Thorn: public P
{

	public:
	Thorn(double yy,int xx,int& w,int& h):P(yy,xx,w,h){}

	virtual void paint(double&v)
	{
		mvaddstr(y,x-2,"     ");
		y-=v;

		mvaddstr(y,x-2,"WWWWW");
	}
	
	virtual void power(Person&,int&){}

	virtual void hp(Person& p1)
	{
		p1.hp = p1.hp-3;
	}
};
