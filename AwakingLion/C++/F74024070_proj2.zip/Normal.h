#include"P.h"

class Normal: public P
{
	public:
	Normal(double yy,int xx,int& w,int& h):P(yy,xx,w,h){}

	virtual void hp(Person& p1)
	{
		p1.hp = (p1.hp<10)?++p1:10;
	}

	virtual void paint(double&v)
	{
		mvaddstr(y,x-2,"     ");
		y-=v;
		mvaddstr(y,x-2,"=====");
	}

	virtual void power(Person&,int&){}


};



