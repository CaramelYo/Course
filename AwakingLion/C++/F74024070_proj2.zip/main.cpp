#include<ncurses.h>
#include<cstdlib>
#include<iostream>
#include"Person.h"
#include"Timer.h"
#include"Normal.h"
#include"Left.h"
#include"Right.h"
#include"Thorn.h"
#include"Spring.h"
#include"Onetime.h"
#define P_Normal 2
#define P_Spring 1
#define P_Thorn 3
#define P_Left 0
#define P_Right 7
#define ALL 8
#define P_Normal2 5
#define P_Normal3 6
#define P_Onetime 4

P* genP(int&,int&);

int main()
{

int width,height,conti=1,conti2 = 2;
int a=0,c =0,s = 0,all =0;
char key;
double x=0,y=10,up=0.00003,yy,xx,down=0.00003,length = 2.0;

initscr();
cbreak();
noecho();
keypad(stdscr,TRUE);
nodelay(stdscr,TRUE);
getmaxyx(stdscr,height,width);
srandom(time(NULL));
mvaddstr(1,0,"VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
width = 80;
Person p1(width);
mvprintw(0,0,"hp : %.2d",p1.hp);
Timer timer;
time_t t;

P *p[5];

while(conti)
{
	if( p1.stand )
	while( (key=getch() ) ==ERR && c == 1)
	{
		mvprintw(0,10,"Time : %.4ld down : %f stair : %.3d",timer.elapsedtime(),down,all);

		if(timer.elapsedtime()%5 == 0)
		{down += 0.00000000001; t= timer.elapsedtime();}
		
		xx = p1.x;
		yy = p1.y;
		p1.y-=up;

		while(p1.y>=height)p1.y-=(height-3);
	
		if(a <5 && timer.elapsedtime() - t > 1)
		{p[a] = genP(width,height);++a; t= timer.elapsedtime();}

		for(int i=0;i<a;++i)
		p[i]->paint(up);
		p[s]->power(p1,c);
		
		if( (p[s]->x - p1.x) > length || (p[s]->x - p1.x) < (-length))
		{p1.stand = 0;c =0 ;break;}
		
		if(p1.y<3)
		{
			{mvaddstr(p[s]->y,p[s]->x-2,"     ");delete p[s];++all;
			p[s] = genP(width,height);}
			
			
			p1.stand = 0;
			c =0;
			p1 = p1-5;
			if(p1.hp<1)
			{conti = 0;break;}
			mvprintw(0,0,"hp : %.2d",p1.hp);
			break;
		}
		
		for(int i=0;i<a;++i)
		{
		if(p[i]->y<3)
		{mvaddstr(p[i]->y,p[i]->x-2,"     ");delete p[i];++all;
		p[i] = genP(width,height);}
		}

		mvaddstr(yy,xx," ");
		mvaddstr(p1.y,p1.x,"0");
	
	}
	else
	while( (key=getch() ) ==ERR && c == 0)
	{
		mvprintw(0,10,"Time : %.4ld down : %f stair : %.3d",timer.elapsedtime(),down,all);

		if(timer.elapsedtime()%5 == 0)
		{down += 0.00000000001;t = timer.elapsedtime();}
		
		xx = p1.x;
		yy = p1.y;
		p1.y += down;

		if(p1.y > height)
		{conti =0;break;}

		if(a < 5 && timer.elapsedtime() - t > 1)
		{p[a] = genP(width,height);++a; t= timer.elapsedtime();}

		if(a)
		{
			for(int i=0;i<a;++i)
			if(  (p[i]->x - p1.x) > (-length) )
			if( (p[i]->x - p1.x) < length)
			if( (p[i]->y > p1.y) )
			if( ( (p[i]->y - p1.y) < 1) )
			{
				p1.stand = 1;
				c=1;
				p[i]->hp(p1);
				mvprintw(0,0,"hp : %.2d",p1.hp);
				s = i;
				break;
			}
			if(c == 1)
			break;
			
		}
		
		for(int i=0;i<a;++i)
		p[i]->paint(up);

		for(int i=0;i<a;++i)
		{
		if(p[i]->y<3)
		{mvaddstr(p[i]->y,p[i]->x-2,"     ");delete p[i];++all;
		p[i] = genP(width,height);}
		}

		mvaddstr(yy,xx," ");
		mvaddstr(p1.y,p1.x,"0");
	}

	switch(key)
	{
		case 'a': 
		mvaddstr(p1.y,p1.x," ");
		p1.x = (p1.x>=1)?--p1.x:0;
		mvaddstr(p1.y,p1.x,"0");break;
		case 'd':
		mvaddstr(p1.y,p1.x," ");
		p1.x = (p1.x<=width)?++p1.x:width;
		mvaddstr(p1.y,p1.x,"0");break;
		case 'q' :
		conti =0;break;
	}

	if(conti ==0)
	while( getch() == ERR )
	mvaddstr(height/2,width/2,"You have been dead,and please key anything to quit");


}
endwin();
return 0;
}

P* genP(int& width,int& height)
{
	int p_type;
	P* pr;
	p_type = random()%ALL;

	switch(p_type)
	{
		case P_Normal:
		pr = new Normal(height,random()%(width-4) +2,width,height);
		break;
		case P_Spring:
		pr = new Spring(height,random()%(width-4) +2,width,height);
		break;
		case P_Thorn:
		pr = new Thorn(height,random()%(width-4) +2,width,height);
		break;
		case P_Left:
		pr = new Left(height,random()%(width-4) +2,width,height);
		break;
		case P_Right:
		pr = new Right(height,random()%(width-4) +2,width,height);
		break;
		case P_Normal2:
		pr = new Normal(height,random()%(width-4) +2,width,height);
		break;
		case P_Normal3:
		pr = new Normal(height,random()%(width-4) +2,width,height);
		break;		
		case P_Onetime:
		pr = new Onetime(height,random()%(width-4) +2,width,height);
		break;
	}
	return pr;
}

