#include"P.h"

class Spring: public P
{

	public:
	Spring(double yy,int xx,int& w,int& h):P(yy,xx,w,h){}

	virtual void hp(Person& p1)
	{
		p1.hp = (p1.hp<10)?++p1:10;
	}

	virtual void paint(double&v)
	{
		mvaddstr(y,x-2,"     ");
		y-=v;
		mvaddstr(y,x-2,"IIIII");
	}

	virtual void power(Person& p1,int& c)
	{
		if(p1.stand)
		{
			p1.y = (p1.y>6)?p1.y-3:2.9;
			p1.stand = 0;
			c = 0;
		}
	}
};
