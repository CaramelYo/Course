#include"P.h"

class Onetime: public P
{
	public:
	Onetime(double yy,int xx,int& w,int& h):P(yy,xx,w,h){}

	virtual void hp(Person&){}

	virtual void paint(double&v)
	{
		mvaddstr(y,x-2,"     ");
		y-=v;
		mvaddstr(y,x-2,"-----");
	}

	virtual void power(Person& p1,int& c)
	{
		if(p1.stand)
		{
			p1.stand = 0;
			c = 0;
		}
	}
};
