#include"Timer.h"

Timer::Timer(){start();}
void Timer::start(){ t = time(NULL); }
time_t Timer::elapsedtime()
{ return ( time(NULL)-t ); }










