#include"Person.h"

Person::Person(int& width)
{
	x = width/2;
	y = 3;
	stand = 0;
	hp = 10;
}

int& Person::operator++()
{
	++hp;
	return hp;
}
Person& Person::operator--()
{
	--hp;
	return (*this);
}


Person& Person::operator-(int d)
{
	hp-=d;
	return (*this);
}

