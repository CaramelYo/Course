#include<iostream>
using namespace std;

class Person
{

	friend class P;
	public:
	Person(int&);
	double x;
	double y;
	int stand;
	int hp;
	int& operator++();
	Person &operator--();
	Person &operator-(int);


};
