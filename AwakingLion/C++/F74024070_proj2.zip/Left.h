#include"P.h"

class Left: public P
{
	public:
	Left(double yy,int xx,int& w,int& h):P(yy,xx,w,h){}

	virtual void paint(double&v)
	{
		mvaddstr(y,x-2,"     ");
		y-=v;
		mvaddstr(y,x-2,"<<<<<");	
	}

	virtual void power(Person& p1,int&)
	{
		if(p1.stand)
		p1.x -= 0.0002;
	}

	virtual void hp(Person& p1)
	{
		p1.hp = (p1.hp<10)?++p1:10;
	}

};





