#include "BMI.h"

void Calculate::setheight(float h){
		height = h/100;
		}
void Calculate::setweight(float w){
		weight = w;
		}
float Calculate::BMI(){
		return weight/height/height;
		}
float Calculate::getheight(){
		return height;
		}
float Calculate::getweight(){
		return weight;
		}

string BMI::judge(float b){
		if(b<15)
		return "Very severely underweight";
		else if(b<16)
			return "Severely underweight";
			else if(b<18.5)
				return "Underweight";
				else if(b<25)
					return "Normal";
					else if(b<30)
						return "Overweight";
						else if(b<35)
							return "Obese Class I (Moderately obese)";
							else if(b<40)
								return "Obese Class II (Severely obese)";
								else if(b>=40)
									return "Obese Class III (Very severely obese)";
		}

