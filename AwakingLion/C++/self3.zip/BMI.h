#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Calculate{
	public :

	void setheight(float h);
	void setweight(float w);
	float BMI();
	float getheight();
	float getweight();
		
	private:
	float height;
	float weight;
		};

class BMI{
	public :

	string  judge(float b);
		
	};
