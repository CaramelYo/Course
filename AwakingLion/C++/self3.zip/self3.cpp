#include <iostream>
#include <string>
#include <fstream>
#include "BMI.h"
using namespace std;

int main()
{
	Calculate cal;
	BMI bmi;
	float h,w;

	ifstream inFILE("file.in",ios::in);
	if(!inFILE)
	{
		cerr<<"error"<<endl;
		return 0;
	}
	
	ofstream outFILE("file.out",ios::out);
	if(!outFILE)
	{
		cerr<<"error"<<endl;
		return 0;
	}

	while(inFILE>>h>>w)
	{
		if(!h&&!w)
		break;
		cal.setheight(h);
		cal.setweight(w);
		outFILE<<cal.BMI()<<"  "<<bmi.judge(cal.BMI())<<endl;

	}

}
