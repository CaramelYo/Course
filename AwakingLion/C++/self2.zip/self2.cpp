#include <iostream>
#include <string>

using namespace std;

class Calculate{

	public:
	void input(int a)
		{
			cout<<"the input number is "<<a<<endl;

			for(;;)
			{
				if(a==1)
				break;
				if(a%2)
				a = 3*a+1;
				else
				a = a/2;
				cout<<"the number is "<<a<<endl;
			}
		}

		};

int main() {

	Calculate cal;
	int p;
	cout<<"please input a number"<<endl;
	cin>>p;
	cal.input(p);
	return 0;
	}
		

