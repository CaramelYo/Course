For question B  , compiling the "self2.cpp"

and input the number  ex: 22